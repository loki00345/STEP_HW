
#1
# file1 = 'file1.txt'
# file2 = 'file2.txt'

# with open(file1, 'r') as f1, open(file2, 'r') as f2:
#     file1_lines = f1.readlines()
#     file2_lines = f2.readlines()

# lines_not_matching = []

# for line1, line2 in zip(file1_lines, file2_lines):
#     if line1.strip() != line2.strip():
#         lines_not_matching.append((line1.strip(), line2.strip()))

# for line1, line2 in lines_not_matching:
#     print(f'У файлі 1: {line1}, у файлі 2: {line2}')


#2
# def count_vowels_consonants_digits(text):
#     vowels = 'aeiou'
#     consonants = 'bcdfghjklmnpqrstvwxyz'
#     digits = '0123456789'
    
#     num_vowels = sum(1 for char in text if char.lower() in vowels)
#     num_consonants = sum(1 for char in text if char.lower() in consonants)
#     num_digits = sum(1 for char in text if char in digits)
    
#     return num_vowels, num_consonants, num_digits

# def count_characters_lines(filename):
#     with open(filename, 'r') as file:
#         text = file.read()
#         num_chars = len(text)
#         num_lines = text.count('\n') + 1
    
#     return num_chars, num_lines

# def main(input_file, output_file):
#     num_chars, num_lines = count_characters_lines(input_file)
#     text = ''
    
#     with open(input_file, 'r') as file:
#         text = file.read()
#         num_vowels, num_consonants, num_digits = count_vowels_consonants_digits(text)
    
#     with open(output_file, 'w') as file:
#         file.write(f'Number of characters: {num_chars}\n')
#         file.write(f'Number of lines: {num_lines}\n')
#         file.write(f'Number of vowels: {num_vowels}\n')
#         file.write(f'Number of consonants: {num_consonants}\n')
#         file.write(f'Number of digits: {num_digits}\n')

# input_file = 'file2.txt'
# output_file = 'file3.txt'

# main(input_file, output_file)


#3
# def remove_last_line(input_file, output_file):
#     with open(input_file, 'r') as file:
#         lines = file.readlines()
#         lines_without_last = lines[:-1]

#     with open(output_file, 'w') as file:
#         file.writelines(lines_without_last)

# input_file = 'file2.txt'
# output_file = 'file3.txt'

# remove_last_line(input_file, output_file)


#4
# def find_longest_line_length(filename):
#     with open(filename, 'r') as file:
#         longest_line_length = max(len(line.strip()) for line in file.readlines())
    
#     return longest_line_length

# input_file = 'file1.txt'
# longest_line_length = find_longest_line_length(input_file)

# print(f'Довжина найдовшого рядка у файлі {input_file} складає {longest_line_length} символів.')


#5
# def count_word_in_file(word, filename):
#     with open(filename, 'r') as file:
#         text = file.read()
#         words = text.split()
#         num_occurrences = sum(1 for w in words if w.lower() == word.lower())
    
#     return num_occurrences

# input_file = 'file1.txt'
# word_to_count = input('Введіть слово для пошуку: ')
# num_occurrences = count_word_in_file(word_to_count, input_file)

# print(f'Слово "{word_to_count}" зустрічається {num_occurrences} разів у файлі {input_file}.')


#6
def replace_word_in_file(old_word, new_word, filename):
    with open(filename, 'r') as file:
        text = file.read()
        replaced_text = text.replace(old_word, new_word)

    with open(filename, 'w') as file:
        file.write(replaced_text)

input_file = 'file1.txt'
old_word = input('Введіть слово для заміни: ')
new_word = input('Введіть нове слово: ')

replace_word_in_file(old_word, new_word, input_file)

print(f'У файлі {input_file} слово "{old_word}" було замінено на "{new_word}".')
