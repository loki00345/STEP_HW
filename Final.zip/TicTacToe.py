def print_board(board):
    for row in board:
        print(" ".join([f"[{cell}]" if cell != " " else "[ ]" for cell in row]))


def get_valid_input(size):
    while True:
        user_input = input(f"Enter row and column (e.g. 1,2): ").strip()
        try:
            row, col = map(int, user_input.split(","))
            if row < 1 or row > size or col < 1 or col > size:
                print(f"Invalid input. Row and column must be between 1 and {size}.")
                continue
            return row, col
        except ValueError:
            print("Invalid input. Please enter two numbers separated by a comma.")


def check_winner(board):
    for row in board:
        if len(set(row)) == 1 and row[0] != " ":
            return row[0]

    for col in range(3):
        if board[0][col] == board[1][col] == board[2][col] and board[0][col] != " ":
            return board[0][col]

    if board[0][0] == board[1][1] == board[2][2] and board[0][0] != " ":
        return board[0][0]

    if board[0][2] == board[1][1] == board[2][0] and board[0][2] != " ":
        return board[0][2]

    return None


def main():
    while True:
        try:
            size = int(input("Enter size of the board (3 or more): "))
            if size < 3:
                print("Invalid input. Size must be at least 3.")
                continue
            break
        except ValueError:
            print("Invalid input. Please enter a number.")

    board = [[" " for _ in range(size)] for _ in range(size)]
    print_board(board)
    current_turn = "X"

    while True:
        row, col = get_valid_input(size)
        if board[row - 1][col - 1] != " ":
            print("This cell is already occupied. Try again.")
            continue

        board[row - 1][col - 1] = current_turn
        print_board(board)

        winner = check_winner(board)
        if winner:
            print(f"Player {winner} wins!")
            break
        elif " " not in [cell for row in board for cell in row]:
            print("It's a tie!")
            break

        current_turn = "X" if current_turn == "O" else "O"


main()
