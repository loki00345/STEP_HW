from tkinter import *

HP = 100
score = 0
press_return = True
f = 'score.txt'
bestScore = 0

def start(event):
    global press_return
    global HP
    global score
    if not press_return:
        pass
    else:
        HP = 100
        score = 0
        label.config(text="")
        update_HP()
        update_display()
        update_points()
        press_return = False

def show_score():
    read_score()
    bestScore_label.config(text=str(bestScore))

def update_display():
    global score
    global HP
    if HP>50:
        bomb_label.config(image = normal_photo)
    elif 0<HP<50:
        bomb_label.config(image = no_photo)
    elif HP<=0:
        bomb_label.config(image = bang_photo)
    fuse_label.config(text="Fuse: " + str(HP))
    score_label.config(text="Score: " + str(score))
    fuse_label.after(100, update_display)

def read_score():
    global f 
    global bestScore
    with open ("score.txt", "r") as f:
       a = f.read()
       bestScore = a

def save_score():
    global bestScore
    global f
    read_score()
    if score > bestScore:
        bestScore = score
        with open("score.txt", "w") as f:
            f.write(str(bestScore))

def update_points():
    global score
    score+=1
    if is_alive():
        score_label.after(3000, update_points)

def update_HP():
    global HP
    HP -= 5
    if is_alive():
        fuse_label.after(400, update_HP)

def is_alive():
    global HP
    global press_return
    if HP<=0:
        label.config(text="L BOZO")
        save_score()
        press_return = True
        return False
    else:
        return True
    
def click():
    global HP
    if is_alive():
        HP += 1

root = Tk()
root.geometry("500x550")
root.title("Bang Bang!!!")

label = Label(root, text="Press [Enter] to start ", font=("Protest Riot", 12))
label.pack()

fuse_label = Label(root, text="Fuse "+str(HP), font=("Protest Riot", 14))
fuse_label.pack() #side=LEFT, anchor="nw", padx=40, pady=20

score_label = Label(root, text="Score "+str(score), font=("Protest Riot", 14))
score_label.pack() #side=RIGHT, anchor="ne", padx=40, pady=20

normal_photo = PhotoImage(file="Images/bomb_normal.gif")
no_photo = PhotoImage(file="Images/bomb_no.gif")
bang_photo = PhotoImage(file="Images/pow.gif")

bomb_label = Label(root, image=normal_photo)
bomb_label.pack()

click_button = Button(root, text="Defuse", command=click, font=("Protest Riot", 14))
click_button.pack()

score_button = Button(root, text="Show best score", command=show_score, font=("Protest Riot", 14))
score_button.place(relx=0.7, rely=0.5)

bestScore_label = Label(root, text='', font=("Protest Riot", 14))
bestScore_label.place(relx=0.8, rely=0.4)

root.bind('<Return>', start)

root.mainloop() 