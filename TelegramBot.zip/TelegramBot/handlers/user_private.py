from aiogram.filters import CommandStart, Command
from aiogram import types, Router, F
import random
from API.api import get_random_duck
from filter.chat_types import ChatTypeFilter

user_private_router = Router()

user_private_router.message.filter(ChatTypeFilter(['private']))

@user_private_router.message(CommandStart())
async def start_cmd(message: types.Message):
    await message.answer(f"Hello my dear friend {message.from_user.full_name}. I`m your personal telegram-bot!")

@user_private_router.message(Command('menu'))
async def menu_cmd(message: types.Message):
    await message.answer("Menu : \n1. /menu \n2. /help \n3. /echo \n4. /start")

@user_private_router.message(Command('help'))
async def help_cmd(message: types.Message):
    await message.answer("If you can't figure out what theese commands mean you should be real worried")

@user_private_router.message(Command('echo'))
async def help_cmd(message: types.Message):
    await message.answer(message.text)

@user_private_router.message(F.text.contains("onn"))
async def pay_method(message: types.Message):
    await message.answer("You can pay for this")

@user_private_router.message(Command('duck'))
async def duck_cmd(message: types.Message):
    url = get_random_duck()
    await message.answer_photo(url)

@user_private_router.message()
async def echo(message: types.Message):
    hello = random.choice(["Hello", "Hi", "Привіт", "Як ся маєш", "Здоровенькі були"])
    byebye = random.choice(["Bye", "Goodbye", "Пака", "Прощавай", "До зустрічі"])
    text = message.text
    if text in ['hi', 'hello', 'привіт', "здоровенькі були"]:
        await message.answer(f"{hello} {message.from_user.full_name}")
    elif text in ['goodbye', 'buy', 'бувай', "пака"]:
        await message.answer(f"{byebye} {message.from_user.full_name}")
    else:
        await message.reply("I don't understand you")
