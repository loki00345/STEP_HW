from aiogram.types import BotCommand

private=[
    BotCommand( command = 'menu', description='Main menu'),
    BotCommand( command = 'duck', description='Random duck image'),
    BotCommand( command = 'help', description='Useless button'),
]